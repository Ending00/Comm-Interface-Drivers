from opendbc.can.packer_pyx import CANPacker # pylint: disable=no-name-in-module, import-error
assert CANPacker
